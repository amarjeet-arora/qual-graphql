export const MONGO_URI='mongodb+srv://amar:amar123@cluster0.rle5i.mongodb.net/qualgraphqldb?retryWrites=true&w=majority'
export const JWT_SECRET="ader1234ioty"