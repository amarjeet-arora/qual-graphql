
export const users=[
    {
        id:"101",
        firstName:"mukesh",
        lastNAme:"Kumar",
        email:"mukesh@mail.com",
        password:"pass123"
    },
    {
        id:"102",
        firstName:"pavan",
        lastNAme:"Kumar",
        email:"pavan@mail.com",
        password:"pass123"
    },
    {
        id:"103",
        firstName:"ritesh",
        lastNAme:"Kumar",
        email:"ritesh@mail.com",
        password:"pass123"
    }
]
export const comments=[
    {
        comment:"wonderful work",
        by:"101"
    },
    {
        comment:"really  nice",
        by:"102"
    }
]