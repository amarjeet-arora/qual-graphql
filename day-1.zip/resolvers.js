import { comments, users } from "./fakeusers.js";
import mongoose from "mongoose";
const User = mongoose.model("User");
const Quote = mongoose.model("Quote");
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "./config.js";
const resolvers = {
  Query: {
    greet: () => "Welcome to GraphQL",
    // user: (_, { _id }) => users.find((user) => user._id == _id),
    // users: () => users,
    //comment: (_, { by }) => comments.find((comment) => comment.by == by),
    //comments: () => comments,
    users: async () => await User.find({}),
    user: async (_,{_id}) => await User.findOne({ _id }),
    comments: async () => await Quote.find({}).populate("by","_id firstName"),
    comment: async (_, { by }) => await Quote.find({ by }),
  },
  User: {
   // comments: (ur) => comments.filter((comment) => comment.by == ur._id),
   comments:async(ur) =>Quote.find({by:ur._id})
  },
  Mutation: {
    signup: async (_, { userNew }) => {
      const user = await User.findOne({ email: userNew.email });
      if (user) {
        throw new Error("User already exist with this email");
      }
      const hp = await bcrypt.hash(userNew.password, 12);
      const newUSer = new User({
        ...userNew,
        password: hp,
      });
      return await newUSer.save();
    },
    signin: async (_, { userSign }) => {
      const user = await User.findOne({ email: userSign.email });
      if (!user) {
        throw new Error("user doesnt exist with that email");
      }
      const doMAtch = await bcrypt.compare(userSign.password, user.password);
      if (!doMAtch) {
        throw new Error("email or password is not valid");
      }
      const token = jwt.sign({ userId: user._id }, JWT_SECRET);
      return { token };
    },
    createComment: async (_, { comment }, { userId }) => {
      if (!userId) throw new Error("User Must be LoggedIN");
      const newComment = new Quote({
        comment,
        by: userId,
      });
      await newComment.save();
      return "Comment Added...!";
    },
  },
};

export default resolvers;
