
import { gql } from "apollo-server";


//define Query
const typeDefs = gql`
  type Query {
    greet: String
    users: [User]
    user(_id: ID): User
    comments: [CommentWithName]
    comment(by: ID): [Comment]
  }
  type CommentWithName{
   comment:String,
   by:IdName
}
  type IdName{
    _id:String
    firstName:String
  }
  type User {
    _id: ID
    firstName: String
    lastNAme: String
    email: String
    comments: [Comment]
  }
  type Comment {
    comment: String
    by: ID
  }
  type Token{
    token:String
  }
  type Mutation{
    signup(userNew:UserInput):User
    signin(userSign:UserSigninInput):Token
    createComment(comment:String):String
  }
  input UserInput {
    firstName:String,
    lastNAme:String,
    email:String,
    password:String
  }
  input UserSigninInput{
    email:String,
    password:String
  }
  
`
export default typeDefs