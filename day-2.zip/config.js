export const MONGO_URI='mongodb+srv://amar:amar123@cluster0.rle5i.mongodb.net/?retryWrites=true&w=majority'
export const JWT_SECRET='abc123456'